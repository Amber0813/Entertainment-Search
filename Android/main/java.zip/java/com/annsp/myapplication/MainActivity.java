package com.annsp.myapplication;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.AutoCompleteTextView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TabHost;
import android.widget.TextView;
import android.graphics.Color;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity implements search.OnFragmentInteractionListener, favorite.OnFragmentInteractionListener {
//    TabHost tabHost;
    String keyword;
    String cat;
    String dist;
    String un;
    String radioloc;
    String inloc;
    RequestQueue mRequestQueue;
    private AutoCompleteTextView autoTextView;
    JSONObject jsonobj;
    TextView temp;
    String url;
    ArrayAdapter<String> autoadapter;
    RadioGroup location;
    private LocationManager locationManager;
    private String locationProvider;
    Location gpslocation;
    JSONObject jsonStringData;
    private List<Fragment> fragments = new ArrayList<>();
    private PagerAdapter adapter;
    TabLayout tabLayout;
    ViewPager viewPager;
    boolean resume;
    favorite fav;

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void setOnResume(boolean res) {
        resume = res;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (resume)
        {
            fav.setR();
            resume = false;

//            allowRefresh = false;
//            lst_applist = db.load_apps();
//            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.mainvp);
        tabLayout = findViewById(R.id.maintb);
        fragments.add(new search());
        fragments.add(new favorite());
        fav = (favorite)fragments.get(1);
        resume = false;
        int i = fragments != null ? fragments.size() : 0;
        String s = Integer.toString(i);
        Log.i("fragmentsize",s);
        adapter = new PagerAdapter(getSupportFragmentManager(), fragments);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });





//        TabHost host = findViewById(R.id.tabHost);
//        autoTextView = findViewById(R.id.autoCompleteTextView);
//        radioloc = "here";
//        temp =  findViewById(R.id.textView);
//        host.setup();
//
//        TabHost.TabSpec spec = host.newTabSpec("favourite");
//        spec.setContent(R.id.search);
//        spec.setIndicator("search");
//        host.addTab(spec);
//
//        spec = host.newTabSpec("favourite");
//        spec.setContent(R.id.favourite);
//        spec.setIndicator("favourite");
//        host.addTab(spec);
//
//        for(int i=0;i<host.getTabWidget().getChildCount();i++)
//        {
//            TextView tv = host.getTabWidget().getChildAt(i).findViewById(android.R.id.title);
//            tv.setTextColor(Color.rgb(255,255,255));
//        }


//        Spinner cate = findViewById(R.id.spinnerCategory);
//        String[] category = {"All","Music","Sports","Arts & Theatre","Film","Miscellaneous"};
//        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,category);
//        cate.setAdapter(adapter);
//        cate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view,
//                                       int pos, long id) {
//
//                String[] category = {"All","Music","Sports","Arts & Theatre","Film","Miscellaneous"};
//                cat = category[pos];
////                Toast.makeText(MainActivity.this, "你点击的是:"+cat, Toast.LENGTH_SHORT).show();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//                // Another interface callback
//            }
//        });
//
//        Spinner uni = findViewById(R.id.spinnerUnit);
//        String[] unit = {"Miles","Kilometers"};
//        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,unit);
//        uni.setAdapter(adapter1);
//        uni.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view,
//                                       int pos, long id) {
//
//                String[] category = {"Miles","Kilometers"};
//                un = category[pos];
////                Toast.makeText(MainActivity.this, "你点击的是:"+un, Toast.LENGTH_SHORT).show();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//                // Another interface callback
//            }
//        });
//
//        //autocomplete
//
//        autoTextView.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                keyword = String.valueOf(autoTextView.getText());
//                mRequestQueue = Volley.newRequestQueue(MainActivity.this);
//                url = "http://mycsci571homeworkann.us-west-1.elasticbeanstalk.com/autocomplete?keyword="+keyword;
//                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
//                        (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
//
//                            @Override
//                            public void onResponse(JSONObject response) {
//                                try {
//                                    jsonobj = response.getJSONObject("_embedded");
//                                    JSONArray att = jsonobj.getJSONArray("attractions");
//                                    String[] names = new String[att.length()];
//                                    for (int i = 0; i < att.length(); i++) {
//                                        names[i] = att.getJSONObject(i).getString("name");
//                                    }
////                                    JSONObject first = att.getJSONObject(0);
//                                    String str = "";
////                                    for (int i = 0; i < names.length; i++)
////                                        str += names[i] + " | ";
////                                    temp.setText("name: " + str);
//                                    autoadapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.select_dialog_item,names);
//                                    autoadapter.notifyDataSetChanged();
//                                    autoTextView.setAdapter(autoadapter);
//                                }
//                                catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        }, new Response.ErrorListener() {
//
//                            @Override
//                            public void onErrorResponse(VolleyError error) {
//                                // TODO: Handle error
//
//                            }
//                        });
//                mRequestQueue.add(jsonObjectRequest);
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//            }
//        });
//        location = findViewById(R.id.locgroup);
//        location.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                RadioButton rb = findViewById(location.getCheckedRadioButtonId());
//                radioloc = rb.getText().toString();
//                if (radioloc.equals("Current location"))
//                    radioloc = "here";
//                else
//                    radioloc = "locinput";
//            }
//        });
//
//
//        Button search = findViewById(R.id.searchButton);
//        search.setOnClickListener(new View.OnClickListener(){
//            public void onClick(View v) {
//                // Code here executes on main thread after user presses button
//                TextView dis = findViewById(R.id.inputDistance);
//                dist = dis.getText().toString();
//                if (un.equals("Kilometers"))
//                    un = "km";
//                else
//                    un = "miles";
//                TextView inputloc = findViewById(R.id.inputloc);
//                inloc = inputloc.getText().toString();
//                JSONObject gpsloc = new JSONObject();
//                try{
//                    gpsloc.put("lat",34.0079);
//                    gpsloc.put("lng",-118.2582);
//                }
//                catch(JSONException e){
//                    Log.i("json",e.getMessage());
//                }
//                String json = gpsloc.toString();
////                temp.setText(keyword+"|"+cat+"|"+dist+"|"+un+"|"+radioloc+"|"+inloc+json);
////                mRequestQueue = Volley.newRequestQueue(MainActivity.this);
//                String resulturl = "http://mycsci571homeworkann.us-west-1.elasticbeanstalk.com/a?keyword="+keyword+"&category="+cat+"&distance="+dist+"&unit="+un+"&location="+radioloc+"&linput="+inloc+"&geo="+json;
//                Log.i("url",resulturl);
//                Intent intent = new Intent(MainActivity.this, results.class);
//                intent.putExtra("resulturl", resulturl);
//                startActivity(intent);
////                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
////                        (Request.Method.GET, resulturl, null, new Response.Listener<JSONObject>() {
////
////                            @Override
////                            public void onResponse(JSONObject response) {
////                                try {
////                                    if (response != null)
////                                    jsonStringData = response.getJSONObject("_embedded");
////                                    JSONArray events = jsonStringData.getJSONArray("events");
////                                    JSONObject e1 = events.getJSONObject(0);
////                                    String name = e1.getString("name");
////                                    temp.setText(name);
////
////
////                                }
////                                catch (JSONException e) {
////                                    jsonStringData = null;
////                                    temp.setText("null");
////                                    e.printStackTrace();
////                                }
////                            }
////                        }, new Response.ErrorListener() {
////
////                            @Override
////                            public void onErrorResponse(VolleyError error) {
////                                // TODO: Handle error
////                                Toast.makeText(MainActivity.this, "Error occurred", Toast.LENGTH_SHORT).show();
////                            }
////                        });
////                mRequestQueue.add(jsonObjectRequest);
//            }
//        });
    }
}
