package com.annsp.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

//public class CustomListAdapter extends ArrayAdapter<JSONObject>{// implements View.OnClickListener
//    private ArrayList<JSONObject> dataSet;
//    Context mContext;
////    String eventid = "";
////ViewHolder viewHolder;
//    private static class ViewHolder {
//        TextView name;
//        TextView place;
//        TextView date;
//        ImageView category;
//        ImageView favorite;
//    }
//
//    public CustomListAdapter(ArrayList<JSONObject> data, Context context) {
//        super(context, R.layout.row_item, data);
//        this.dataSet = data;
//        this.mContext=context;
//    }
////    public void onClick(View v) {
////
////        Toast.makeText(mContext, "favorite",
////                Toast.LENGTH_SHORT).show();
//////        int position=(Integer) v.getTag();
//////        Object object= getItem(position);
//////        JSONObject jsonitem=(JSONObject)object;
////
////    }
//
//
//    public View getView(final int position, View convertView, ViewGroup parent) {
//        // Get the data item for this position
//        final JSONObject jsonitem = dataSet.get(position);
//        // Check if an existing view is being reused, otherwise inflate the view
//        ViewHolder viewHolder; // view lookup cache stored in tag
//
//        final View result;
//
//        if (convertView == null) {
//
//            viewHolder = new ViewHolder();
//            LayoutInflater inflater = LayoutInflater.from(getContext());
//            convertView = inflater.inflate(R.layout.row_item, parent, false);
//            viewHolder.name = (TextView) convertView.findViewById(R.id.name);
//            viewHolder.place = (TextView) convertView.findViewById(R.id.place);
//            viewHolder.date = (TextView) convertView.findViewById(R.id.date);
//            viewHolder.category = (ImageView) convertView.findViewById(R.id.category);
//            viewHolder.favorite = (ImageView) convertView.findViewById(R.id.favorite);
//
//            convertView.setTag(viewHolder);
//        } else {
//            viewHolder = (ViewHolder) convertView.getTag();
//        }
//
//        String strname = "";
//        String strplace = "";
//        String strdate = "";
////        String eventid = "";
//        try {
//            strname = jsonitem.getString("name");
//            final String eventid = jsonitem.getString("id");
//            JSONObject json = jsonitem.getJSONObject("_embedded");
//            JSONArray venues = json.getJSONArray("venues");
//            JSONObject venue = venues.getJSONObject(0);
//            strplace = venue.getString("name");
//            JSONObject dates = jsonitem.getJSONObject("dates");
//            JSONObject start = dates.getJSONObject("start");
//            if (start.has("localTime")){
//                strdate = start.getString("localDate") + " " + start.getString("localTime");
//            }
//            else
//                strdate = start.getString("localDate");
//            JSONArray classifications = jsonitem.getJSONArray("classifications");
//            JSONObject classification = classifications.getJSONObject(0);
//            JSONObject segment = classification.getJSONObject("segment");
//            String catid = segment.getString("id");
//            switch(catid) {
//                case "KZFzniwnSyZfZ7v7nJ":
//                    viewHolder.category.setImageResource(R.drawable.music_icon);
//                    break;
//                case "KZFzniwnSyZfZ7v7nE":
//                    viewHolder.category.setImageResource(R.drawable.sport_icon);
//                    break;
//                case "KZFzniwnSyZfZ7v7na":
//                    viewHolder.category.setImageResource(R.drawable.art_icon);
//                    break;
//                case "KZFzniwnSyZfZ7v7nn":
//                    viewHolder.category.setImageResource(R.drawable.film_icon);
//                    break;
//                case "KZFzniwnSyZfZ7v7n1":
//                    viewHolder.category.setImageResource(R.drawable.miscellaneous_icon);
//                    break;
//            }
//            viewHolder.favorite.setOnClickListener(new View.OnClickListener(){
//                @Override
//                public void onClick(View v) {
//                    SharedPreferences favorite = mContext.getSharedPreferences("favorite",mContext.MODE_PRIVATE) ;
//                    String favid = favorite.getString(eventid,"novalue");
//                    Log.i("favoriteeventid", favid);
//                    if (favid.equals("novalue")){
//                        String favitems = favorite.getString("events", "noevents");
//                        if (favitems.equals("noevents")) {
//                            JSONObject json = new JSONObject();
//                            try {
////                                JSONObject eventitem = new JSONObject(eventitemstr);
//                                json.put(eventid, jsonitem);
//                            }
//                            catch(JSONException e) {
//                                Log.i("parsejsonerr", e.getMessage());
//                            }
//                            String jsonstr = json.toString();
//                            favorite.edit().putString("events",jsonstr).apply();
//                            favorite.edit().putString(eventid,"has").apply();
//                        }
//                        else {
//                            try {
//                                JSONObject json = new JSONObject(favitems);
////                                JSONObject eventitem = new JSONObject(eventitemstr);
//                                json.put(eventid, jsonitem);
//                                String jsonstr = json.toString();
//                                favorite.edit().putString("events",jsonstr).apply();
//                                favorite.edit().putString(eventid,"has").apply();
//                            }
//                            catch(JSONException e) {
//                                Log.i("favjsonerr", e.getMessage());
//                            }
//                        }
//                        viewHolder.favorite.setImageResource(R.drawable.heart_fill_red);
//                    }
//                    else {
//                        String favitems = favorite.getString("events", "noevents");
//                        try {
//                            JSONObject json = new JSONObject(favitems);
//                            json.remove(eventid);
//                            String jsonstr = json.toString();
//                            favorite.edit().putString("events",jsonstr).apply();
//                            favorite.edit().remove(eventid).apply();
//                        }
//                        catch(JSONException e) {
//                            Log.i("favjsonerr", e.getMessage());
//                        }
//                        viewHolder.favorite.setImageResource(R.drawable.heart_outline_black);
//                    }
//                }
//            });
//        }
//        catch (JSONException e) {
//            e.printStackTrace();
//        }
//        Log.i("adapter",strname+" "+strplace+" "+strdate);
//        viewHolder.name.setText(strname);
//        viewHolder.place.setText(strplace);
//        viewHolder.date.setText(strdate);
//        viewHolder.favorite.setImageResource(R.drawable.heart_outline_black);
//
//        viewHolder.favorite.setTag(position);
//        // Return the completed view to render on screen
//        return convertView;
//    }
//
//    public void updateview(int position) {
//
//    }
//}
